package com.cg.onlinelearning.dto;

import java.math.BigInteger;

public class Student {
private String name;
private BigInteger phoneNumber;
private String emailAddress;
private Address address;
public Student(){
}
public Student(String name, BigInteger phoneNumber, String emailAddress, Address address) {
	super();
	this.name = name;
	this.phoneNumber = phoneNumber;
	this.emailAddress = emailAddress;
	this.address = address;}
public String getName() {
	return name;}
public void setName(String name) {
	this.name = name;}
public BigInteger getPhoneNumber() {
	return phoneNumber;}
public void setPhoneNumber(BigInteger phoneNumber) {
	this.phoneNumber = phoneNumber;}
public String getEmailAddress() {
	return emailAddress;}
public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;}
public Address getAddress() {
	return address;}
public void setAddress(Address address) {
	this.address = address;}
@Override
public String toString() {
	return "Student [name=" + name + ", phoneNumber=" + phoneNumber + ", emailAddress=" + emailAddress + ", address="
			+ address + "]";
}}
