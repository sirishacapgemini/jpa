package com.cg.onlinelearning.ui;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.*;

import com.cg.onlinelearning.dto.Address;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.service.CourseService;
import com.cg.onlinelearning.service.CourseServiceImplement;
import com.cg.onlinelearning.util.DBUtil;
public class Application {
	static CourseService service;
    public static void main( String[] args ) throws CourseNotFoundException{
      service=new CourseServiceImplement();
      Scanner sc=new Scanner(System.in);
      int choice=0;
   do{
   	printDetails();
   	System.out.println("enter the choice");
   	choice=sc.nextInt();
   	switch(choice) {
   	case 1://add the course
   		System.out.println("enter the course id");
   		int id=sc.nextInt();
   		System.out.println("enter course name");
   		String name=sc.next();
   		Course cooo=new Course();
   		cooo.setId(id);
   		cooo.setSubject(name);
   		try {
			service.add(cooo);
		} catch (CourseNotFoundException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
			//System.out.println(e4.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   		System.out.println("Course added successfully");
   		break;
   	case 2://show all courses
   		List<Course> myList;
		try {
			myList = service.showAllCourses();
			for(Course courseData:myList) {
				System.out.println("CourseId is "+courseData.getId());
				System.out.println("CourseName is "+courseData.getSubject());
			}
		} catch (CourseNotFoundException e3) {
			// TODO Auto-generated catch block
			System.out.println(e3.getMessage());
		}break;
   	case 3://register for course
   		
   		System.out.println("enter the course subject");
   		String courseName=sc.next();
   		try {
			service.searchBySubject(courseName);
		} catch (CourseNotFoundException e2) {
			// TODO Auto-generated catch block
			System.err.println(e2.getMessage());
			break;}
		System.out.println("enter student name");
		String snameOne=sc.next();
		System.out.println("enter the phone number");
		BigInteger phnNo=sc.nextBigInteger();
		System.out.println("enter the mailId");
		String emailId=sc.next();
		System.out.println("enter the state");
		String state=sc.next();
		System.out.println("enter the city");
		String city=sc.next();
		System.out.println("enter the pincode");
		int pinCode=sc.nextInt();
		Address addressOne=new Address(state,city,pinCode);
		Student stuOne=new Student(snameOne,phnNo,emailId,addressOne);
		
		try {
	   		service.registerForCourse(courseName, stuOne);
			} catch (CourseNotFoundException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
				System.err.println(e1.getMessage());
				break;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   	        System.err.println("registered successfully");
	   	       System.out.println(stuOne);
			   break;
   	case 4://search
   		System.out.println("enter the course subject to search");
   		String sname=sc.next();
   		List<Student> studentSearch=null;
          try {
			studentSearch = service.searchBySubject(sname);
          }catch (CourseNotFoundException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
				System.err.println(e1.getMessage());
				break;}
			for (Student student : studentSearch) {
				System.out.println("Student name is "+ student.getName());
				System.out.println("Phone number is "+student.getPhoneNumber());
				System.out.println("Email address is "+student.getEmailAddress());
				System.out.println("Address is "+student.getAddress());
			}
			
   		break;
   		default:System.err.println("Incorrect choice");
   		break;}}while(choice!=5);}
    static void printDetails() {
	System.out.println("1.Add course");
	System.out.println("2.show all courses");
	System.out.println("3.Register for course");
	System.out.println("4.search by course subject name");
	}}