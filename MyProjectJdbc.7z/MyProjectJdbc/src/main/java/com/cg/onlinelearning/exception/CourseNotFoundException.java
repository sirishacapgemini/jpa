package com.cg.onlinelearning.exception;

public class CourseNotFoundException extends Exception {

	public CourseNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CourseNotFoundException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	
}
