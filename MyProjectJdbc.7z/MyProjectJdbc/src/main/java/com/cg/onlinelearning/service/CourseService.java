package com.cg.onlinelearning.service;
import java.sql.SQLException;
import java.util.List;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
public interface CourseService {
public Course registerForCourse(String subject,Student students) throws CourseNotFoundException, SQLException;
public Course add(Course course) throws CourseNotFoundException, SQLException;
public List<Student> searchBySubject(String subject) throws CourseNotFoundException;
public List<Course> showAllCourses() throws CourseNotFoundException;}
