package com.cg.onlinelearning.repository;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.cg.onlinelearning.dto.Address;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.util.DBUtil;
public class CourseRepositoryImplement implements CourseRepository{
	Connection conn=null;
	PreparedStatement pstm=null;
	ResultSet result=null;
	//saving course object
	public Course save(Course course) throws CourseNotFoundException{
		// TODO Auto-generated method stud
		int c_id=0;
	Course cou=null;
	
		try {
			
			cou = findBySubject(course.getSubject());
		} catch (CourseNotFoundException e1) {
			// TODO Auto-generated catch block
		}
		if(course.getStudents()!=null) {
			
			Student student=course.getStudents().get(0);
			//System.out.println(student.getAddress().getCity());
		       String queryOne="insert into address(city,state,pincode) values(?,?,?)";
				try {
					conn=DBUtil.getConnection();
						pstm=conn.prepareStatement(queryOne);
						pstm.setString(1, student.getAddress().getCity());
						pstm.setString(2, student.getAddress().getState());
						pstm.setInt(3, student.getAddress().getPinCode());
						int resOne=pstm.executeUpdate();
						int a_id=0;
						if(resOne>0) {
							String queryTwo="select max(addId) from address";
							pstm=conn.prepareStatement(queryTwo);
							result=pstm.executeQuery();
							if(result.next()) {
								a_id=result.getInt(1);
							}}
						String queryTwo="insert into student(name,phonenumber,emailaddress,addId,cid) values(?,?,?,?,?)";
						pstm=conn.prepareStatement(queryTwo);
						pstm.setString(1, student.getName());
						pstm.setString(2, student.getPhoneNumber().toString());
						pstm.setString(3, student.getEmailAddress());
						pstm.setInt(4, a_id);
						pstm.setInt(5,course.getId());
						pstm.executeUpdate();
						if(resOne>0)
							return cou;
			
					} catch (SQLException e1) {
						//e1.printStackTrace();
						throw new CourseNotFoundException("course not found");
					} catch (CourseNotFoundException e) {
						// TODO Auto-generated catch block
						throw new CourseNotFoundException("course not found");
					}
		}
					
		else {
		
		try {
			cou = findBySubject(course.getSubject());
			conn=DBUtil.getConnection();
			String query="insert into course values(?,?)";
			try {
				pstm=conn.prepareStatement(query);
				pstm.setInt(1, course.getId());
				pstm.setString(2, course.getSubject());
				int res=pstm.executeUpdate();
		       //c_id=course.getId();
		       //System.out.println(c_id);
		       return course;
		       
						
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new CourseNotFoundException("course not found");
		}

	}catch (CourseNotFoundException e) {
		// TODO Auto-generated catch block
		throw new CourseNotFoundException("course not found");
	
		}
		finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new CourseNotFoundException("course not found");
			}
			
		}
		
		}
		return course;
		}
	
	//finding course subject from the database
	public Course findBySubject(String subject) throws CourseNotFoundException{
		// TODO Auto-generated method stud
		Course courseOne=null;
		List<Student> stu=new ArrayList<Student>();
		try {
			conn=DBUtil.getConnection();
		} catch (CourseNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new CourseNotFoundException("course not found");
		}
		courseOne=new Course();
		try {
			PreparedStatement pstmOne=conn.prepareStatement("select c.cid from course c where c.Subject=?");
			pstmOne.setString(1,subject);
			ResultSet res=pstmOne.executeQuery();
			while(res.next()) {
				courseOne.setId(res.getInt(1));
				courseOne.setSubject(subject);
			}
			
			pstm=conn.prepareStatement("select s.cid, s.name,s.phonenumber,s.emailaddress,a.city,a.state,a.pincode from student s inner join address a on s.addId=a.addId where s.cid=(select cid from course c where Subject=?)");
			pstm.setString(1, subject);
			result=	pstm.executeQuery();
			while(result.next())
			{
			    
				Student s=new Student(result.getString(2), new BigInteger(result.getString(3)),result.getString(4),new Address(result.getString(5), result.getString(6),result.getInt(7)));
			     stu.add(s);
				courseOne.setStudents(stu);
				//System.out.println(cou);
				return courseOne;

			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new CourseNotFoundException("course not found");
		}
		finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				throw new CourseNotFoundException("course not found");
			}
			
		}
		return courseOne;
		
	}
    //showing all the courses which are there in the database
	public List<Course> showAllCourses() throws CourseNotFoundException {
		// TODO Auto-generated method stub
		Connection conn=DBUtil.getConnection();
		String query="select * from course";
		PreparedStatement pstm = null;
		List<Course> myList=new ArrayList<Course>();
		try {
			pstm=conn.prepareStatement(query);
			ResultSet result=pstm.executeQuery();
			while(result.next()) {
				Course cou=new Course();
				cou.setId(result.getInt(1)); 
				cou.setSubject(result.getString(2));
				myList.add(cou);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new CourseNotFoundException("show not working");
		}finally {
			try {
				pstm.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new CourseNotFoundException("course not found");
			}

		}


		return myList;
	}
	
}
